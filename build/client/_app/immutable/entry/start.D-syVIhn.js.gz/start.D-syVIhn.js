import{a as t}from"../chunks/entry.D41oB5Id.js";export{t as start};
