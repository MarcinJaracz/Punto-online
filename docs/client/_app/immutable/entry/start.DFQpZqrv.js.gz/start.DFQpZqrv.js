import{b as a}from"../chunks/entry.DkswO31u.js";export{a as start};
