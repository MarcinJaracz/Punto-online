import{b as a}from"../chunks/entry.CfF-g6aw.js";export{a as start};
